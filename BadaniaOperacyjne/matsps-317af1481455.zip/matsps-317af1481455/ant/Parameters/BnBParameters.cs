﻿using System;
using System.Collections.Generic;
using System.Text;

using matsps.CommonData;

namespace matsps.Parameters
{
    /// <summary>
    /// Класс с параметрами расчета алгоритма Ветвей и границ
    /// </summary>
    class BnBParameters : IParameters
    {
        public BnBParameters()
        {
        }
    }
}

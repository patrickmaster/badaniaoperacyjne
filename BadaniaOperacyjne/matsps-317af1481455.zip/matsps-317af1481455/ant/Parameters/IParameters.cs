﻿using System;
using System.Collections.Generic;
using System.Text;

namespace matsps.Parameters
{
    /// <summary>
    /// Интерфейс параметров алгоритма
    /// </summary>
    interface IParameters       
    {
    }
}

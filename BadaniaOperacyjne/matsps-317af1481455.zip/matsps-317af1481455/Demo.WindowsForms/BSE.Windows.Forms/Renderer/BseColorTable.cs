﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BSE.Windows.Forms
{
    /// <summary>
    /// Baseclass for a colortable for the <see cref="BseRenderer"/>
    /// </summary>
    public class BseColorTable : BSE.Windows.Forms.ProfessionalColorTable
    {
    }
}
